# Mkhoa - App giải trí FFVN

App Android **chỉ mang tính giải trí**. Các chức năng Aim Lock, Nhẹ Tâm, Fix Lag... **không có tác dụng thật**.

## Tính năng giao diện
- Hoa anh đào rơi liên tục
- 7 nút bật/tắt chức năng giả
- Khi bật → hiện "Đang bật vui lòng đợi..." 2 giây
- Sau đó hiện "Vui lòng vào game FFVN"
- Ghi chú rõ: chỉ để vui, không có hiệu quả

## Cách build APK

### Yêu cầu
- Android Studio Hedgehog trở lên
- JDK 17

### Các bước
1. Mở Android Studio → Open → chọn thư mục `MkhoaApp`
2. Đợi Gradle sync xong
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. APK nằm ở: `app/build/outputs/apk/debug/app-debug.apk`

### Cài đặt
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Lưu ý quan trọng
**Không có chức năng nào can thiệp game.**  
Toàn bộ chỉ là UI giả để vui.
