# Keep everything for this fun app
-keep class com.mkhoa.app.** { *; }
