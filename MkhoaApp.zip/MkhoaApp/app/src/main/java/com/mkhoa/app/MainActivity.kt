package com.mkhoa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MkhoaTheme {
                MkhoaScreen()
            }
        }
    }
}

@Composable
fun MkhoaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFF69B4),
            secondary = Color(0xFFFFB7C5),
            background = Color(0xFF1A0A2E),
            surface = Color(0xFF2D1B4E)
        ),
        content = content
    )
}

data class Feature(
    val name: String,
    val description: String,
    var isOn: Boolean = false
)

@Composable
fun MkhoaScreen() {
    val features = remember {
        mutableStateListOf(
            Feature("Aim Lock", "Khóa tâm tự động"),
            Feature("Nhẹ Tâm", "Giảm độ nặng tâm"),
            Feature("Fix Lag", "Giảm lag khi chơi"),
            Feature("Fix Lố", "Sửa lỗi lố đạn"),
            Feature("Fix Nặng Tâm", "Tâm nhẹ hơn"),
            Feature("Tăng FPS", "Tăng khung hình"),
            Feature("Mượt Mà", "Làm mượt trải nghiệm")
        )
    }

    var showLoading by remember { mutableStateOf(false) }
    var loadingMessage by remember { mutableStateOf("") }
    var showSuccess by remember { mutableStateOf(false) }
    var currentFeatureIndex by remember { mutableStateOf(-1) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A0A2E))
    ) {
        // Falling sakura petals
        SakuraPetals()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Text(
                text = "Mkhoa",
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF69B4),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, bottom = 4.dp),
                textAlign = TextAlign.Center
            )
            Text(
                text = "Công cụ hỗ trợ FFVN",
                fontSize = 14.sp,
                color = Color(0xFFFFB7C5),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                textAlign = TextAlign.Center
            )

            // Feature list
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
            ) {
                features.forEachIndexed { index, feature ->
                    FeatureToggle(
                        feature = feature,
                        enabled = !showLoading,
                        onToggle = { isOn ->
                            if (isOn && !feature.isOn) {
                                features[index] = feature.copy(isOn = true)
                                currentFeatureIndex = index
                                showLoading = true
                                loadingMessage = "Đang bật vui lòng đợi..."
                                showSuccess = false
                            } else if (!isOn && feature.isOn) {
                                features[index] = feature.copy(isOn = false)
                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            // Footer note
            Text(
                text = "⚠ Các chức năng chỉ mang tính giải trí\nKhông có tác dụng thực tế",
                fontSize = 12.sp,
                color = Color(0xFFFFB7C5).copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )
        }

        // Loading overlay
        if (showLoading) {
            LoadingOverlay(
                message = loadingMessage,
                onFinished = {
                    showLoading = false
                    showSuccess = true
                }
            )
        }

        // Success dialog
        if (showSuccess) {
            SuccessDialog(
                onDismiss = { showSuccess = false }
            )
        }
    }
}

@Composable
fun FeatureToggle(
    feature: Feature,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D1B4E).copy(alpha = 0.85f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = feature.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    text = feature.description,
                    fontSize = 12.sp,
                    color = Color(0xFFFFB7C5).copy(alpha = 0.8f)
                )
            }
            Switch(
                checked = feature.isOn,
                onCheckedChange = onToggle,
                enabled = enabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(0xFFFF69B4),
                    uncheckedThumbColor = Color.White,
                    uncheckedTrackColor = Color(0xFF4A3A6A)
                )
            )
        }
    }
}

@Composable
fun LoadingOverlay(
    message: String,
    onFinished: () -> Unit
) {
    LaunchedEffect(Unit) {
        delay(2000)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF2D1B4E)
            )
        ) {
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(
                    color = Color(0xFFFF69B4),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = message,
                    color = Color.White,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun SuccessDialog(onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF2D1B4E)
            ),
            modifier = Modifier.padding(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "✓ Đã bật thành công",
                    color = Color(0xFFFF69B4),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Vui lòng vào game FFVN",
                    color = Color.White,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF69B4)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("OK", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun SakuraPetals() {
    val petals = remember {
        List(40) {
            PetalState(
                x = Random.nextFloat(),
                y = Random.nextFloat() * -1f,
                size = Random.nextFloat() * 12f + 6f,
                speed = Random.nextFloat() * 1.5f + 0.8f,
                sway = Random.nextFloat() * 2f + 1f,
                rotation = Random.nextFloat() * 360f,
                rotationSpeed = Random.nextFloat() * 2f - 1f,
                alpha = Random.nextFloat() * 0.5f + 0.4f
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "petals")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(100000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "time"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        petals.forEach { petal ->
            val progress = (time * petal.speed * 0.01f + petal.y) % 1.2f
            val y = progress * (height + 50f) - 25f
            val x = petal.x * width + sin(progress * 10f * petal.sway) * 30f * petal.sway
            val rot = petal.rotation + time * petal.rotationSpeed * 0.5f

            if (y > -30f && y < height + 30f) {
                drawSakuraPetal(
                    center = Offset(x, y),
                    size = petal.size,
                    rotation = rot,
                    alpha = petal.alpha
                )
            }
        }
    }
}

data class PetalState(
    val x: Float,
    val y: Float,
    val size: Float,
    val speed: Float,
    val sway: Float,
    val rotation: Float,
    val rotationSpeed: Float,
    val alpha: Float
)

fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSakuraPetal(
    center: Offset,
    size: Float,
    rotation: Float,
    alpha: Float
) {
    val path = Path().apply {
        // Simple 5-petal sakura shape
        val r = size
        moveTo(center.x, center.y - r)
        for (i in 0 until 5) {
            val angle1 = Math.toRadians((i * 72 - 90).toDouble())
            val angle2 = Math.toRadians((i * 72 - 90 + 36).toDouble())
            val angle3 = Math.toRadians(((i + 1) * 72 - 90).toDouble())

            val x1 = center.x + (r * 0.4f * Math.cos(angle1)).toFloat()
            val y1 = center.y + (r * 0.4f * Math.sin(angle1)).toFloat()
            val x2 = center.x + (r * Math.cos(angle2)).toFloat()
            val y2 = center.y + (r * Math.sin(angle2)).toFloat()
            val x3 = center.x + (r * 0.4f * Math.cos(angle3)).toFloat()
            val y3 = center.y + (r * 0.4f * Math.sin(angle3)).toFloat()

            cubicTo(x1, y1, x2, y2, x3, y3)
        }
        close()
    }

    rotate(rotation, center) {
        drawPath(
            path = path,
            color = Color(0xFFFFB7C5).copy(alpha = alpha)
        )
        // Center
        drawCircle(
            color = Color(0xFFFF69B4).copy(alpha = alpha * 0.8f),
            radius = size * 0.15f,
            center = center
        )
    }
}
